/**
 * app.js — Bootstrap + Echo init (Laravel Mix / Webpack)
 *
 * This file runs FIRST (loaded before game.js in Blade layout).
 * It sets up window.axios and window.Echo so game.js can use them.
 */

// ── Bootstrap ────────────────────────────────────────────────────────────────
import 'bootstrap';

// ── Axios ────────────────────────────────────────────────────────────────────
import axios from 'axios';

window.axios = axios;
window.axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
window.axios.defaults.headers.common['Accept']           = 'application/json';

// CSRF token from meta tag
const csrfMeta = document.head.querySelector('meta[name="csrf-token"]');
if (csrfMeta) {
    window.axios.defaults.headers.common['X-CSRF-TOKEN'] = csrfMeta.content;
}

// Sanctum Bearer token (set after guestLogin API call)
const storedToken = localStorage.getItem('auth_token');
if (storedToken) {
    window.axios.defaults.headers.common['Authorization'] = `Bearer ${storedToken}`;
}

// ── Laravel Echo (WebSocket via Reverb) ──────────────────────────────────────
import Echo from 'laravel-echo';
import Pusher from 'pusher-js';

window.Pusher = Pusher;

// Read config from the DOM (injected by Blade via data attributes or meta tags)
// Falls back to process.env values baked in by Mix at build time
const reverbKey    = document.querySelector('meta[name="reverb-key"]')?.content
                  || process.env.MIX_REVERB_APP_KEY
                  || 'lucky-puffin-key';

const reverbHost   = document.querySelector('meta[name="reverb-host"]')?.content
                  || process.env.MIX_REVERB_HOST
                  || 'localhost';

const reverbPort   = parseInt(
    document.querySelector('meta[name="reverb-port"]')?.content
    || process.env.MIX_REVERB_PORT
    || '8080'
);

const reverbScheme = document.querySelector('meta[name="reverb-scheme"]')?.content
                  || process.env.MIX_REVERB_SCHEME
                  || 'http';

window.Echo = new Echo({
    broadcaster:       'reverb',
    key:               reverbKey,
    wsHost:            reverbHost,
    wsPort:            reverbPort,
    wssPort:           reverbPort,
    forceTLS:          reverbScheme === 'https',
    enabledTransports: ['ws', 'wss'],
    authEndpoint:      '/broadcasting/auth',
    auth: {
        headers: {
            // Auth header for private channels — updated after login
            Authorization: localStorage.getItem('auth_token')
                ? `Bearer ${localStorage.getItem('auth_token')}`
                : '',
        },
    },
});

// ── Signal that Echo is ready ─────────────────────────────────────────────────
// game.js listens for this event before subscribing to channels
window.echoReady = true;
document.dispatchEvent(new CustomEvent('echo:ready'));

console.log('[App] Echo initialized on', `${reverbScheme}://${reverbHost}:${reverbPort}`);
